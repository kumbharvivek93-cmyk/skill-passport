# Skill Bar AI

Skill Bar AI is a Flask MVP focused on evidence-backed skills, practical assessments, scorecards, and digital passports.

## Getting started

1. Create a virtual environment.
2. Install dependencies:
   pip install -r requirements.txt
3. Run the app:
   python app.py

## Demo workflow

- Register a Candidate account.
- Add a GitHub URL via the repository form.
- Open the challenge catalogue and begin a Python challenge.
- Run the demo sandboxed assessment.
- Review results and issue a passport.

## Notes

- This V1 uses a demo-safe code execution mode rather than executing untrusted code in the main Flask server.
- The project stores demonstration data in SQLite for local development.
