document.addEventListener('DOMContentLoaded', () => {
  const flashEls = document.querySelectorAll('.flash');
  flashEls.forEach((el) => {
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transition = 'opacity 0.4s';
    }, 2500);
  });
});
