from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from skill_bar_ai.extensions import db
from skill_bar_ai.models.assessment import Assessment
from skill_bar_ai.models.challenge import Challenge
from skill_bar_ai.models.repository import Repository
from skill_bar_ai.models.passport import SkillPassport


dashboard_bp = Blueprint("dashboard", __name__, url_prefix="")


@dashboard_bp.route("/dashboard")
@login_required
def index():
    repos = Repository.query.filter_by(user_id=current_user.id).all()
    assessments = Assessment.query.filter_by(user_id=current_user.id).order_by(Assessment.started_at.desc()).all()
    passport = SkillPassport.query.filter_by(user_id=current_user.id).order_by(SkillPassport.issue_date.desc()).first()

    skills = []
    for repo in repos:
        for evidence in repo.evidences:
            skills.append(evidence.skill_name)

    return render_template(
        "dashboard.html",
        repos=repos,
        assessments=assessments,
        passport=passport,
        skills=sorted(set(skills)),
        user=current_user,
    )


@dashboard_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        current_user.name = (request.form.get("name") or current_user.name).strip()
        current_user.role = request.form.get("role") or current_user.role
        db.session.commit()
        flash("Profile updated.", "success")
        return redirect(url_for("dashboard.profile"))

    return render_template("profile.html", user=current_user)
