import base64
from io import BytesIO

import qrcode
from flask import Blueprint, flash, redirect, render_template, send_file, url_for
from flask_login import current_user, login_required

from skill_bar_ai.extensions import db
from skill_bar_ai.models.passport import SkillPassport
from skill_bar_ai.services.passport_service import issue_passport_for_user, verify_passport
from skill_bar_ai.services.pdf_service import create_scorecard_pdf, create_id_card_pdf


passports_bp = Blueprint("passports", __name__, url_prefix="")


@passports_bp.route("/passports")
@login_required
def index():
    passports = SkillPassport.query.filter_by(user_id=current_user.id).all()
    return render_template("passport_preview.html", passports=passports)


@passports_bp.route("/passport/issue")
@login_required
def issue():
    passport = issue_passport_for_user(current_user)
    flash("Skill Passport issued successfully.", "success")
    return redirect(url_for("passports.preview", passport_id=passport.id))


@passports_bp.route("/passport/<int:passport_id>")
@login_required
def preview(passport_id):
    passport = SkillPassport.query.get_or_404(passport_id)
    if passport.user_id != current_user.id and current_user.role != "Admin":
        return redirect(url_for("dashboard.index"))

    qr_img = qrcode.make(f"http://localhost:5000/verify/{passport.public_id}")
    qr_buffer = BytesIO()
    qr_img.save(qr_buffer, format="PNG")
    qr_buffer.seek(0)

    qr_data_uri = "data:image/png;base64," + base64.b64encode(qr_buffer.getvalue()).decode("utf-8")
    return render_template("passport_detail.html", passport=passport, qr_image=qr_data_uri)


@passports_bp.route("/passport/<int:passport_id>/scorecard")
@login_required
def scorecard(passport_id):
    passport = SkillPassport.query.get_or_404(passport_id)
    if passport.user_id != current_user.id and current_user.role != "Admin":
        return redirect(url_for("dashboard.index"))
    pdf = create_scorecard_pdf(passport)
    return send_file(pdf, mimetype="application/pdf", download_name=f"scorecard-{passport.public_id}.pdf")


@passports_bp.route("/passport/<int:passport_id>/id-card")
@login_required
def id_card(passport_id):
    passport = SkillPassport.query.get_or_404(passport_id)
    if passport.user_id != current_user.id and current_user.role != "Admin":
        return redirect(url_for("dashboard.index"))
    pdf = create_id_card_pdf(passport)
    return send_file(pdf, mimetype="application/pdf", download_name=f"id-card-{passport.public_id}.pdf")


@passports_bp.route("/passport/<int:passport_id>/revoke", methods=["POST"])
@login_required
def revoke(passport_id):
    passport = SkillPassport.query.get_or_404(passport_id)
    if passport.user_id != current_user.id and current_user.role != "Admin":
        return redirect(url_for("dashboard.index"))
    passport.revoked = True
    passport.status = "revoked"
    db.session.commit()
    flash("Passport revoked.", "success")
    return redirect(url_for("passports.preview", passport_id=passport.id))


@passports_bp.route("/verify/<public_id>")
def verify(public_id):
    passport = verify_passport(public_id)
    if not passport:
        return render_template("passport_verify.html", valid=False, message="Credential not found.")
    return render_template("passport_verify.html", valid=True, passport=passport)
