from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from skill_bar_ai.extensions import db
from skill_bar_ai.models.evidence import Evidence
from skill_bar_ai.models.repository import Repository
from skill_bar_ai.services.github_service import analyse_repository_url, validate_github_url


repos_bp = Blueprint("repositories", __name__, url_prefix="")


@repos_bp.route("/repositories", methods=["GET", "POST"])
@login_required
def index():
    if request.method == "POST":
        repo_url = (request.form.get("repository_url") or "").strip()
        if not validate_github_url(repo_url):
            flash("Please submit a valid public GitHub repository URL.", "error")
            return render_template("repository_form.html", repo_url=repo_url)

        repo_data = analyse_repository_url(repo_url)
        repo = Repository(
            user_id=current_user.id,
            repository_url=repo_url,
            repository_name=repo_data["repository_name"],
            language=repo_data.get("language", "Python"),
            description=repo_data.get("description", "Imported from GitHub"),
            status="analyzed",
        )
        db.session.add(repo)
        db.session.commit()

        for skill in repo_data.get("skills", []):
            evidence = Evidence(
                repository_id=repo.id,
                skill_name=skill,
                file_path=repo_data.get("file_path", "README.md"),
                evidence_description=f"Evidence from {repo.repository_name}: {skill} demonstrates practical repository usage.",
                source_type="github",
                confidence=0.7,
                review_status="reviewed",
            )
            db.session.add(evidence)
        db.session.commit()

        flash("Repository analyzed and evidence recorded.", "success")
        return redirect(url_for("repositories.index"))

    repos = Repository.query.filter_by(user_id=current_user.id).all()
    return render_template("repositories.html", repos=repos)


@repos_bp.route("/repositories/new")
@login_required
def new_repository():
    return render_template("repository_form.html")
