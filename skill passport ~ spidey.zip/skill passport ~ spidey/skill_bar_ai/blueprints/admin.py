from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from skill_bar_ai.extensions import db
from skill_bar_ai.models.challenge import Challenge


admin_bp = Blueprint("admin", __name__, url_prefix="")


@admin_bp.route("/admin")
@login_required
def index():
    if current_user.role != "Admin":
        return render_template("error.html", title="Access denied", message="Administrator access required."), 403
    challenges = Challenge.query.order_by(Challenge.created_at.desc()).all()
    return render_template("admin.html", challenges=challenges)


@admin_bp.route("/admin/challenge", methods=["POST"])
@login_required
def create_challenge():
    if current_user.role != "Admin":
        return render_template("error.html", title="Access denied", message="Administrator access required."), 403

    challenge = Challenge(
        title=request.form.get("title") or "New challenge",
        description=request.form.get("description") or "A practical coding challenge.",
        target_skill=request.form.get("target_skill") or "Python",
        difficulty=request.form.get("difficulty") or "Medium",
        rubric_json={"functional": 40, "quality": 20, "approach": 20, "understanding": 20},
        public_tests_json=[{"name": "smoke", "expected": "pass"}],
        time_limit=int(request.form.get("time_limit") or 45),
    )
    db.session.add(challenge)
    db.session.commit()
    flash("Challenge added.", "success")
    return redirect(url_for("admin.index"))
