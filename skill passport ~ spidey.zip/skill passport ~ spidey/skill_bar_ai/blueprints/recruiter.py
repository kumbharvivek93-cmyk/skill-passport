from flask import Blueprint, render_template
from flask_login import current_user, login_required

from skill_bar_ai.models.passport import SkillPassport


recruiter_bp = Blueprint("recruiter", __name__, url_prefix="")


@recruiter_bp.route("/recruiter")
@login_required
def index():
    if current_user.role not in {"Recruiter", "Admin"}:
        return render_template("error.html", title="Access denied", message="Recruiter access required."), 403
    passports = SkillPassport.query.filter_by(status="issued").all()
    return render_template("recruiter.html", passports=passports)
