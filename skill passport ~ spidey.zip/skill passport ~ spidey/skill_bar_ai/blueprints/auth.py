from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import login_user, logout_user, login_required, current_user

from skill_bar_ai.extensions import db
from skill_bar_ai.models.user import User


auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        confirm = request.form.get("confirm_password") or ""
        role = request.form.get("role") or "Candidate"
        if role == "Administrator":
            role = "Admin"

        if not name or not email or len(password) < 6:
            flash("Please provide a valid name, email, and password with at least 6 characters.", "error")
            return render_template("auth.html", mode="register", title="Register")
        if password != confirm:
            flash("Passwords do not match.", "error")
            return render_template("auth.html", mode="register", title="Register")
        if User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "error")
            return render_template("auth.html", mode="register", title="Register")

        user = User(name=name, email=email, role=role)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash("Registration successful. Please log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("auth.html", mode="register", title="Register")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        user = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            login_user(user)
            flash("Welcome back.", "success")
            return redirect(url_for("dashboard.index"))

        flash("Invalid email or password.", "error")
        return render_template("auth.html", mode="login", title="Login")

    return render_template("auth.html", mode="login", title="Login")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "success")
    return redirect(url_for("auth.login"))
