from datetime import datetime

from flask import Blueprint, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from skill_bar_ai.extensions import db
from skill_bar_ai.models.activity import ActivityEvent
from skill_bar_ai.models.assessment import Assessment
from skill_bar_ai.models.challenge import Challenge
from skill_bar_ai.models.code_run import CodeRun
from skill_bar_ai.models.submission import Submission
from skill_bar_ai.services.challenge_service import get_challenge_catalogue, get_or_create_assessment
from skill_bar_ai.services.code_runner import run_code_demo
from skill_bar_ai.services.scoring_service import score_assessment


assessments_bp = Blueprint("assessments", __name__, url_prefix="")


@assessments_bp.route("/assessments")
def catalogue():
    challenges = get_challenge_catalogue()
    return render_template("challenge_catalogue.html", challenges=challenges)


@assessments_bp.route("/assessments/<int:challenge_id>", methods=["GET", "POST"])
@login_required
def challenge_detail(challenge_id):
    challenge = Challenge.query.get_or_404(challenge_id)
    assessment = get_or_create_assessment(current_user.id, challenge.id)

    if request.method == "POST" and request.form.get("action") == "submit":
        submission_code = request.form.get("source_code") or ""
        submission = Submission(
            assessment_id=assessment.id,
            source_code=submission_code,
            version_number=1,
            test_results_json={"passed": True, "summary": "Submitted for human review."},
        )
        db.session.add(submission)
        assessment.status = "submitted"
        assessment.submitted_at = datetime.utcnow()
        assessment.evaluation_status = "pending"
        db.session.commit()
        ActivityEvent.create(assessment.id, "assessment_submitted", {"version": 1})
        return redirect(url_for("assessments.result", assessment_id=assessment.id))

    return render_template("assessment_detail.html", challenge=challenge, assessment=assessment)


@assessments_bp.route("/assessments/<int:assessment_id>/ide")
@login_required
def ide(assessment_id):
    assessment = Assessment.query.get_or_404(assessment_id)
    if assessment.user_id != current_user.id:
        return redirect(url_for("dashboard.index"))
    challenge = assessment.challenge
    return render_template("ide.html", assessment=assessment, challenge=challenge)


@assessments_bp.route("/assessments/<int:assessment_id>/run", methods=["POST"])
@login_required
def run_assessment(assessment_id):
    assessment = Assessment.query.get_or_404(assessment_id)
    if assessment.user_id != current_user.id:
        return jsonify({"error": "Unauthorized"}), 403

    code = request.json.get("code", "") if request.is_json else request.form.get("code", "")
    challenge = assessment.challenge
    result = run_code_demo(code, challenge)

    code_run = CodeRun(
        assessment_id=assessment.id,
        status=result["status"],
        exit_code=result.get("exit_code", 0),
        stdout_limited=result.get("stdout", ""),
        stderr_limited=result.get("stderr", ""),
        execution_time=result.get("execution_time", 0.0),
    )
    db.session.add(code_run)
    ActivityEvent.create(assessment.id, "code_run", {"status": result["status"], "stdout": result.get("stdout", "")[:200]})
    db.session.commit()
    return jsonify(result)


@assessments_bp.route("/assessments/<int:assessment_id>/result")
@login_required
def result(assessment_id):
    assessment = Assessment.query.get_or_404(assessment_id)
    if assessment.user_id != current_user.id:
        return redirect(url_for("dashboard.index"))

    rubric = assessment.challenge.rubric_json or {"functional": 40, "quality": 20, "approach": 20, "understanding": 20}
    score_summary = score_assessment(assessment, rubric)
    return render_template("result.html", assessment=assessment, score_summary=score_summary)
