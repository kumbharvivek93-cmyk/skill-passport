from flask import Flask, redirect, render_template

from .config import Config
from .extensions import db, login_manager, migrate
from .blueprints.auth import auth_bp
from .blueprints.dashboard import dashboard_bp
from .blueprints.repositories import repos_bp
from .blueprints.assessments import assessments_bp
from .blueprints.passports import passports_bp
from .blueprints.recruiter import recruiter_bp
from .blueprints.admin import admin_bp
from .models.user import User


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(Config)

    if test_config:
        app.config.from_mapping(test_config)

    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @login_manager.unauthorized_handler
    def handle_unauthorized():
        return redirect('/login')

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(repos_bp)
    app.register_blueprint(assessments_bp)
    app.register_blueprint(passports_bp)
    app.register_blueprint(recruiter_bp)
    app.register_blueprint(admin_bp)

    @app.route('/')
    def landing_page():
        return render_template('landing.html')

    @app.errorhandler(404)
    def not_found(error):
        return render_template('error.html', title='Page Not Found', message='The page you requested does not exist.'), 404

    @app.errorhandler(500)
    def server_error(error):
        return render_template('error.html', title='Something went wrong', message='An internal server error occurred.'), 500

    with app.app_context():
        db.create_all()
        from .services.challenge_service import seed_challenges
        seed_challenges()

    return app
