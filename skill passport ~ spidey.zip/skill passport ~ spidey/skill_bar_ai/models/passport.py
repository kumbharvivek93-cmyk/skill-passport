import uuid
from datetime import datetime

from skill_bar_ai.extensions import db


class SkillPassport(db.Model):
    __tablename__ = "skill_passports"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    public_id = db.Column(db.String(80), unique=True, nullable=False, index=True)
    issue_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(40), default="issued")
    target_role = db.Column(db.String(120), nullable=False)
    public_fields_json = db.Column(db.JSON, default=dict)
    revoked = db.Column(db.Boolean, default=False)

    user = db.relationship("User", back_populates="passports")

    @staticmethod
    def create_for_user(user, target_role="Python Developer"):
        passport = SkillPassport(
            user_id=user.id,
            public_id=str(uuid.uuid4()),
            target_role=target_role,
            public_fields_json={"display_name": user.name, "role": target_role},
        )
        db.session.add(passport)
        db.session.commit()
        return passport
