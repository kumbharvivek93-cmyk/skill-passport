from datetime import datetime

from skill_bar_ai.extensions import db


class CodeRun(db.Model):
    __tablename__ = "code_runs"

    id = db.Column(db.Integer, primary_key=True)
    assessment_id = db.Column(db.Integer, db.ForeignKey("assessments.id"), nullable=False)
    status = db.Column(db.String(60), default="queued")
    exit_code = db.Column(db.Integer, nullable=True)
    stdout_limited = db.Column(db.Text, default="")
    stderr_limited = db.Column(db.Text, default="")
    execution_time = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    assessment = db.relationship("Assessment", back_populates="code_runs")
