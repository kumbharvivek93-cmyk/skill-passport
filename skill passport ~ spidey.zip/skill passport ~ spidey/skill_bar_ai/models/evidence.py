from datetime import datetime

from skill_bar_ai.extensions import db


class Evidence(db.Model):
    __tablename__ = "evidence"

    id = db.Column(db.Integer, primary_key=True)
    repository_id = db.Column(db.Integer, db.ForeignKey("repositories.id"), nullable=False)
    skill_name = db.Column(db.String(120), nullable=False)
    file_path = db.Column(db.String(255), nullable=True)
    evidence_description = db.Column(db.Text, nullable=False)
    source_type = db.Column(db.String(80), default="repository")
    confidence = db.Column(db.Float, default=0.5)
    review_status = db.Column(db.String(40), default="pending")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    repository = db.relationship("Repository", back_populates="evidences")
