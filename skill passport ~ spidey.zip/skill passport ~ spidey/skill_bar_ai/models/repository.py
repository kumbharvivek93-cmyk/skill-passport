from datetime import datetime

from skill_bar_ai.extensions import db


class Repository(db.Model):
    __tablename__ = "repositories"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    repository_url = db.Column(db.String(255), nullable=False)
    repository_name = db.Column(db.String(200), nullable=False)
    language = db.Column(db.String(80), default="Python")
    description = db.Column(db.Text)
    status = db.Column(db.String(40), default="submitted")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", back_populates="repositories")
    evidences = db.relationship("Evidence", back_populates="repository", cascade="all, delete-orphan")
