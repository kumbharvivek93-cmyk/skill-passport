from skill_bar_ai.extensions import db


class ScoreCriterion(db.Model):
    __tablename__ = "score_criteria"

    id = db.Column(db.Integer, primary_key=True)
    assessment_id = db.Column(db.Integer, db.ForeignKey("assessments.id"), nullable=False)
    criterion_name = db.Column(db.String(80), nullable=False)
    max_points = db.Column(db.Float, default=0.0)
    awarded_points = db.Column(db.Float, default=0.0)
    justification = db.Column(db.Text, default="")
    evidence_reference = db.Column(db.String(255), default="")
    evaluation_method = db.Column(db.String(80), default="manual")

    assessment = db.relationship("Assessment", back_populates="score_criteria")
