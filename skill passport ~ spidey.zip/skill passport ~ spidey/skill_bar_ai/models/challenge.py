from datetime import datetime

from skill_bar_ai.extensions import db


class Challenge(db.Model):
    __tablename__ = "challenges"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    target_skill = db.Column(db.String(120), nullable=False)
    difficulty = db.Column(db.String(40), default="Medium")
    rubric_json = db.Column(db.JSON, default=lambda: {
        "functional": 40,
        "quality": 20,
        "approach": 20,
        "understanding": 20,
    })
    public_tests_json = db.Column(db.JSON, default=list)
    hidden_test_reference = db.Column(db.String(255), nullable=True)
    time_limit = db.Column(db.Integer, default=45)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    assessments = db.relationship("Assessment", back_populates="challenge")
