from datetime import datetime

from skill_bar_ai.extensions import db


class Submission(db.Model):
    __tablename__ = "submissions"

    id = db.Column(db.Integer, primary_key=True)
    assessment_id = db.Column(db.Integer, db.ForeignKey("assessments.id"), nullable=False)
    source_code = db.Column(db.Text, nullable=False)
    version_number = db.Column(db.Integer, default=1)
    test_results_json = db.Column(db.JSON, default=dict)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    assessment = db.relationship("Assessment", back_populates="submissions")
