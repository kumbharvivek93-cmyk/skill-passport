from datetime import datetime

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from skill_bar_ai.extensions import db


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(40), default="Candidate")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    repositories = db.relationship("Repository", back_populates="user", cascade="all, delete-orphan")
    assessments = db.relationship("Assessment", back_populates="user", cascade="all, delete-orphan")
    passports = db.relationship("SkillPassport", back_populates="user", cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
