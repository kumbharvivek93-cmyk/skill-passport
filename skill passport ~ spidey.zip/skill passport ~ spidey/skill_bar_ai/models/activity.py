from datetime import datetime

from skill_bar_ai.extensions import db


class ActivityEvent(db.Model):
    __tablename__ = "activity_events"

    id = db.Column(db.Integer, primary_key=True)
    assessment_id = db.Column(db.Integer, db.ForeignKey("assessments.id"), nullable=False)
    event_type = db.Column(db.String(80), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    metadata_json = db.Column(db.JSON, default=dict)

    assessment = db.relationship("Assessment", back_populates="activity_events")

    @staticmethod
    def create(assessment_id, event_type, metadata=None):
        event = ActivityEvent(assessment_id=assessment_id, event_type=event_type, metadata_json=metadata or {})
        db.session.add(event)
        db.session.commit()
        return event
