from datetime import datetime

from skill_bar_ai.extensions import db


class Assessment(db.Model):
    __tablename__ = "assessments"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    challenge_id = db.Column(db.Integer, db.ForeignKey("challenges.id"), nullable=False)
    status = db.Column(db.String(40), default="in_progress")
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    submitted_at = db.Column(db.DateTime, nullable=True)
    total_score = db.Column(db.Float, default=0.0)
    evaluation_status = db.Column(db.String(40), default="pending")

    user = db.relationship("User", back_populates="assessments")
    challenge = db.relationship("Challenge", back_populates="assessments")
    submissions = db.relationship("Submission", back_populates="assessment", cascade="all, delete-orphan")
    activity_events = db.relationship("ActivityEvent", back_populates="assessment", cascade="all, delete-orphan")
    code_runs = db.relationship("CodeRun", back_populates="assessment", cascade="all, delete-orphan")
    score_criteria = db.relationship("ScoreCriterion", back_populates="assessment", cascade="all, delete-orphan")
