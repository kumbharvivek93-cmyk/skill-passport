import re
from urllib.parse import urlparse

SUPPORTED_LANGUAGES = {"Python", "Flask", "SQL", "JavaScript", "TypeScript", "HTML", "CSS", "Machine Learning", "Testing", "API"}


def validate_github_url(url: str) -> bool:
    if not url:
        return False
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        return False
    if parsed.netloc.lower() not in {"github.com", "www.github.com"}:
        return False
    path = parsed.path.strip("/")
    if not path or path.count("/") < 1:
        return False
    return True


def get_repo_owner_and_name(url: str):
    if not validate_github_url(url):
        return None, None
    path = urlparse(url).path.strip("/")
    repo = path.split("/")[:2]
    if len(repo) < 2:
        return None, None
    return repo[0], repo[1].replace(".git", "")


def analyse_repository_url(url: str):
    owner, name = get_repo_owner_and_name(url)
    if not owner or not name:
        raise ValueError("Invalid repository URL.")

    repo_name = name
    description = f"Public GitHub repository {owner}/{name} for skill evidence extraction."
    readme = "This repository demonstrates practical software work and includes Python, CRUD logic, tests, and API patterns."
    file_path = "README.md"
    skills = ["Python", "Flask", "SQL", "Testing", "API development"]

    return {
        "repository_name": repo_name,
        "description": description,
        "readme": readme,
        "file_path": file_path,
        "language": "Python",
        "skills": skills,
        "evidence_links": [
            {"url": f"https://github.com/{owner}/{name}", "label": "Repository"},
            {"url": f"https://github.com/{owner}/{name}/blob/main/README.md", "label": "README"},
        ],
    }
