from skill_bar_ai.extensions import db
from skill_bar_ai.models.passport import SkillPassport


def issue_passport_for_user(user, target_role="Python Developer"):
    passport = SkillPassport.query.filter_by(user_id=user.id).order_by(SkillPassport.issue_date.desc()).first()
    if passport and passport.status != "revoked":
        return passport
    passport = SkillPassport.create_for_user(user, target_role=target_role)
    return passport


def verify_passport(public_id):
    return SkillPassport.query.filter_by(public_id=public_id).first()
