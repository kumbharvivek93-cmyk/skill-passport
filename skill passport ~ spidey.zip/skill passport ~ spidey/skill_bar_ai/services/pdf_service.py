from io import BytesIO

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def create_scorecard_pdf(passport):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    story = [
        Paragraph("Skill Bar AI Scorecard", styles["Title"]),
        Spacer(1, 20),
        Paragraph(f"Candidate: {passport.user.name}", styles["BodyText"]),
        Paragraph(f"Passport ID: {passport.public_id}", styles["BodyText"]),
        Paragraph(f"Target Role: {passport.target_role}", styles["BodyText"]),
        Paragraph("Assessment Summary: Verified skill evidence, challenge attempt, and rubric review.", styles["BodyText"]),
        Spacer(1, 20),
        Paragraph("This PDF is evidence of the server-side record, not proof of skill by itself.", styles["BodyText"]),
    ]
    doc.build(story)
    buffer.seek(0)
    return buffer


def create_id_card_pdf(passport):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    data = [
        ["Skill Bar AI", "Passport ID"],
        [passport.user.name, passport.public_id],
        [passport.target_role, "Verified"],
    ]
    table = Table(data, colWidths=[200, 200])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f2a44")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
        ("GRID", (0, 0), (-1, -1), 1, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))

    story = [
        Paragraph("Skill Bar AI ID Card", styles["Title"]),
        Spacer(1, 20),
        Paragraph(f"Candidate: {passport.user.name}", styles["BodyText"]),
        table,
        Spacer(1, 20),
        Paragraph(f"Issue Date: {passport.issue_date.date() if passport.issue_date else 'n/a'}", styles["BodyText"]),
    ]
    doc.build(story)
    buffer.seek(0)
    return buffer
