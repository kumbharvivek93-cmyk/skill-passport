from skill_bar_ai.extensions import db
from skill_bar_ai.models.assessment import Assessment
from skill_bar_ai.models.challenge import Challenge


DEFAULT_CHALLENGES = [
    {
        "title": "Python Debugging",
        "description": "Fix a Python function that fails with edge cases and returns incorrect values for empty and repeated inputs.",
        "target_skill": "Python",
        "difficulty": "Medium",
        "time_limit": 30,
        "public_tests_json": [{"name": "basic_case", "example": "assert solve([1,2,3]) == 6"}],
        "rubric_json": {"functional": 40, "quality": 20, "approach": 20, "understanding": 20},
    },
    {
        "title": "Feature Modification",
        "description": "Update a small Flask API so it validates request data and returns structured error messages without breaking its existing endpoints.",
        "target_skill": "Flask",
        "difficulty": "Hard",
        "time_limit": 45,
        "public_tests_json": [{"name": "api_contract", "example": "status code 400 on invalid payload"}],
        "rubric_json": {"functional": 40, "quality": 20, "approach": 20, "understanding": 20},
    },
]


def seed_challenges():
    count = Challenge.query.count()
    if count:
        return
    for item in DEFAULT_CHALLENGES:
        challenge = Challenge(**item)
        db.session.add(challenge)
    db.session.commit()


def get_challenge_catalogue():
    return Challenge.query.order_by(Challenge.id.asc()).all()


def get_or_create_assessment(user_id, challenge_id):
    assessment = Assessment.query.filter_by(user_id=user_id, challenge_id=challenge_id).order_by(Assessment.started_at.desc()).first()
    if assessment:
        return assessment
    assessment = Assessment(user_id=user_id, challenge_id=challenge_id, status="in_progress")
    db.session.add(assessment)
    db.session.commit()
    return assessment
