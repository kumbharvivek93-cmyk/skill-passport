import time


def run_code_demo(code: str, challenge=None):
    start = time.time()
    if not code or not code.strip():
        return {
            "status": "failed",
            "exit_code": 1,
            "stdout": "",
            "stderr": "No code submitted.",
            "execution_time": round(time.time() - start, 3),
        }

    lower = code.lower()
    if "def" in lower and "return" in lower:
        stdout = "Demo runner: code syntax looks valid and challenge checks are ready for human review."
        stderr = ""
        exit_code = 0
        status = "passed"
    else:
        stdout = "Demo runner: template recognized but no executable function was supplied."
        stderr = "Please provide a function definition and return value."
        exit_code = 1
        status = "failed"

    return {
        "status": status,
        "exit_code": exit_code,
        "stdout": stdout,
        "stderr": stderr,
        "execution_time": round(time.time() - start, 3),
    }
