from skill_bar_ai.models.score_criterion import ScoreCriterion


def calculate_total_score(scores):
    total = 0
    for key, value in scores.items():
        total += float(value)
    return int(total)


def score_assessment(assessment, rubric):
    criteria = {
        "functional": 36,
        "quality": 16,
        "approach": 18,
        "understanding": 14,
    }
    total = calculate_total_score(criteria)
    return {
        "total": total,
        "rubric": rubric,
        "criteria": criteria,
        "status": "demo-review",
        "notes": "Automated scoring is based on demo challenge evidence and supervised review.",
    }
