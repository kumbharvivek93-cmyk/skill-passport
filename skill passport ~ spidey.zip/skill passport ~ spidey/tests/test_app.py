import pytest

from skill_bar_ai import create_app


@pytest.fixture
def client():
    app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:"})
    app.config["WTF_CSRF_ENABLED"] = False
    with app.test_client() as client:
        yield client


def test_registration_and_login(client):
    res = client.post(
        "/register",
        data={
            "name": "Ada",
            "email": "ada@example.com",
            "password": "secret123",
            "confirm_password": "secret123",
            "role": "Candidate",
        },
        follow_redirects=True,
    )
    assert res.status_code == 200
    assert b"Login" in res.data or b"Dashboard" in res.data

    login = client.post(
        "/login",
        data={"email": "ada@example.com", "password": "secret123"},
        follow_redirects=True,
    )
    assert login.status_code == 200


def test_protected_route_requires_auth(client):
    res = client.get("/dashboard")
    assert res.status_code == 302


def test_repository_url_validation(client):
    from skill_bar_ai.services.github_service import validate_github_url

    assert validate_github_url("https://github.com/octocat/Hello-World") is True
    assert validate_github_url("https://example.com/foo") is False


def test_challenge_catalogue(client):
    res = client.get("/assessments")
    assert res.status_code == 200
    assert b"Python Debugging" in res.data or b"Challenge" in res.data


def test_scoring_calculation():
    from skill_bar_ai.services.scoring_service import calculate_total_score

    assert calculate_total_score({"functional": 36, "quality": 16, "approach": 18, "understanding": 14}) == 84


def test_passport_issue(client):
    app = client.application
    with app.app_context():
        from skill_bar_ai.models.user import User
        from skill_bar_ai.models.passport import SkillPassport

        user = User(name="Test User", email="test@example.com", role="Candidate")
        user.set_password("secret123")
        from skill_bar_ai.extensions import db
        db.session.add(user)
        db.session.commit()

        passport = SkillPassport.create_for_user(user, target_role="Python Developer")
        assert passport.public_id
        assert passport.status == "issued"
        assert passport.user_id == user.id


def test_invalid_input_and_error_response(client):
    res = client.post("/register", data={"name": "", "email": "bad", "password": "1", "confirm_password": "2"}, follow_redirects=True)
    assert res.status_code == 200
    assert b"error" in res.data.lower() or b"invalid" in res.data.lower() or b"password" in res.data.lower()
